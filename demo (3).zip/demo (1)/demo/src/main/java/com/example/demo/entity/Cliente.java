package com.example.demo.entity;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "clientes")
@PrimaryKeyJoinColumn(name = "usuario_id")
public class Cliente extends Usuario {

    private String direccion;
    private String telefono;

    // RELACIÓN MUCHOS A MUCHOS (MxM) - OBLIGATORIA PARA SPRINT 2
    // Un cliente puede tener muchos servicios favoritos y un servicio puede ser favorito de muchos clientes.
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "cliente_servicios_favoritos",
            joinColumns = @JoinColumn(name = "cliente_id"),
            inverseJoinColumns = @JoinColumn(name = "servicio_id")
    )
    private Set<Servicio> serviciosFavoritos = new HashSet<>();

    public Cliente() {
        super();
    }

    public Cliente(String username, String email, String password, String direccion, String telefono) {
        super(username, email, password);
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Set<Servicio> getServiciosFavoritos() {
        return serviciosFavoritos;
    }

    public void setServiciosFavoritos(Set<Servicio> serviciosFavoritos) {
        this.serviciosFavoritos = serviciosFavoritos;
    }
}