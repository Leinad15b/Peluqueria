package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = "grupos_usuarios")
@PrimaryKeyJoinColumn(name = "usuario_id")
public class Grupo extends Usuario {

    private String nombreEmpresa;
    private String cif;

    public Grupo() {
        super();
    }

    public Grupo(String username, String email, String password, String nombreEmpresa, String cif) {
        super(username, email, password);
        this.nombreEmpresa = nombreEmpresa;
        this.cif = cif;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }
}