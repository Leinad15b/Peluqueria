package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class HomeController {

    @GetMapping("/")
    public Map<String, String> home() {
        return Map.of(
                "status", "✅ API Peluquería funcionando",
                "endpoints", "/api/servicios",
                "swagger", "/swagger-ui/index.html",
                "api-docs", "/v3/api-docs"
        );
    }
}
