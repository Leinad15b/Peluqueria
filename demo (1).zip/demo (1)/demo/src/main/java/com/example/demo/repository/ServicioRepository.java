package com.example.demo.repository;

import com.example.demo.entity.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServicioRepository extends JpaRepository<Servicio, Long> {

    @Query(value = "SELECT * FROM servicio s WHERE s.precio BETWEEN :min AND :max", nativeQuery = true)
    List<Servicio> findByPrecioBetween(@Param("min") Double min, @Param("max") Double max);

    @Query(value = "SELECT * FROM servicio s WHERE s.descripcion LIKE CONCAT('%', :keyword, '%')", nativeQuery = true)
    List<Servicio> searchByDescripcion(@Param("keyword") String keyword);
}
