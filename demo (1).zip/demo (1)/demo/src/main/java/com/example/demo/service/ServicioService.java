package com.example.demo.service;

import com.example.demo.entity.Servicio;
import com.example.demo.repository.ServicioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicioService {

    @Autowired
    private ServicioRepository servicioRepository;

    public List<Servicio> findAll() {
        return servicioRepository.findAll();
    }

    public Optional<Servicio> findById(Long id) {
        return servicioRepository.findById(id);
    }

    public Servicio save(Servicio servicio) {
        return servicioRepository.save(servicio);
    }

    public Servicio update(Long id, Servicio servicio) {
        return servicioRepository.findById(id)
                .map(existing -> {
                    existing.setNombre(servicio.getNombre());
                    existing.setPrecio(servicio.getPrecio());
                    existing.setDuracion(servicio.getDuracion());
                    existing.setDescripcion(servicio.getDescripcion());
                    return servicioRepository.save(existing);
                })
                .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));
    }

    public void delete(Long id) {
        servicioRepository.deleteById(id);
    }
}
