package com.example.demo.controller;

import com.example.demo.entity.Servicio;
import com.example.demo.service.ServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/servicios")
public class ServicioController {

    @Autowired
    private ServicioService servicioService;

    @GetMapping
    public List<Servicio> listarServicios() {
        return servicioService.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Servicio> obtenerServicio(@PathVariable Long id) {
        Optional<Servicio> servicio = servicioService.obtenerPorId(id);
        if (servicio.isPresent()) {
            return ResponseEntity.ok(servicio.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Servicio> crearServicio(@RequestBody Servicio servicio) {
        Servicio nuevoServicio = servicioService.guardar(servicio);
        return ResponseEntity.ok(nuevoServicio);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Servicio> actualizarServicio(@PathVariable Long id, @RequestBody Servicio servicioDetalles) {
        Optional<Servicio> servicioOptional = servicioService.obtenerPorId(id);

        if (servicioOptional.isPresent()) {
            Servicio servicio = servicioOptional.get();
            servicio.setNombre(servicioDetalles.getNombre());
            servicio.setDescripcion(servicioDetalles.getDescripcion());
            servicio.setPrecio(servicioDetalles.getPrecio());
            servicio.setDuracionBloques(servicioDetalles.getDuracionBloques());
            servicio.setTipoServicio(servicioDetalles.getTipoServicio());

            return ResponseEntity.ok(servicioService.guardar(servicio));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarServicio(@PathVariable Long id) {
        if (servicioService.existePorId(id)) {
            servicioService.eliminar(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}