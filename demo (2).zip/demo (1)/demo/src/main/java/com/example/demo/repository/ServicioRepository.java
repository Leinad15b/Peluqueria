package com.example.demo.repository;

import com.example.demo.entity.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServicioRepository extends JpaRepository<Servicio, Long> {

    @Query(value = "SELECT * FROM servicios WHERE precio >= ?1", nativeQuery = true)
    List<Servicio> buscarPorPrecioMinimoNativo(double precio);

    List<Servicio> findByNombreContaining(String nombre);
}