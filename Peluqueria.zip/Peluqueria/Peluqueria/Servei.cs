﻿namespace GestioPeluqueria
{
    public class Servei
    {
        public string Nom { get; set; }
        public string Descripcio { get; set; }
        public decimal Preu { get; set; }
        public string Categoria { get; set; }
        public float Puntuacio { get; set; }

        public Servei(string nom, string descripcio, decimal preu, string categoria, float puntuacio)
        {
            Nom = nom;
            Descripcio = descripcio;
            Preu = preu;
            Categoria = categoria;
            Puntuacio = puntuacio;
        }
    }
}