﻿namespace GestioPeluqueria
{
    partial class frmServicis
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            // Definicions dels controls amb nomenclatura homogènia
            this.lblSalutacioUsuari = new System.Windows.Forms.Label();
            this.txtCercarServei = new System.Windows.Forms.TextBox();
            this.lblTitolServeis = new System.Windows.Forms.Label();
            this.btnCategoriaPopulares = new System.Windows.Forms.Button();
            this.btnCategoriaBaratos = new System.Windows.Forms.Button();
            this.btnCategoriaMujeres = new System.Windows.Forms.Button();
            this.pnlServeiExemple = new System.Windows.Forms.Panel();
            this.lblNomServei = new System.Windows.Forms.Label();
            this.lblUbicacioServei = new System.Windows.Forms.Label();
            this.lblPuntuacioServei = new System.Windows.Forms.Label();
            this.btnTornarHome = new System.Windows.Forms.Button();

            this.pnlServeiExemple.SuspendLayout();
            this.SuspendLayout();

            // --- Propietats dels Controls ---

            // lblSalutacioUsuari
            this.lblSalutacioUsuari.AutoSize = true;
            this.lblSalutacioUsuari.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSalutacioUsuari.Location = new System.Drawing.Point(30, 30);
            this.lblSalutacioUsuari.Name = "lblSalutacioUsuari";
            this.lblSalutacioUsuari.Size = new System.Drawing.Size(130, 26);
            this.lblSalutacioUsuari.Text = "Hola, David";

            // txtCercarServei (TextBox de cerca)
            this.txtCercarServei.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCercarServei.Location = new System.Drawing.Point(30, 70);
            this.txtCercarServei.Name = "txtCercarServei";
            this.txtCercarServei.Size = new System.Drawing.Size(354, 26);
            this.txtCercarServei.TabIndex = 1;
            this.txtCercarServei.Text = "Buscar servicio..."; // Text de suggeriment

            // lblTitolServeis
            this.lblTitolServeis.AutoSize = true;
            this.lblTitolServeis.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitolServeis.Location = new System.Drawing.Point(30, 120);
            this.lblTitolServeis.Name = "lblTitolServeis";
            this.lblTitolServeis.Size = new System.Drawing.Size(91, 22);
            this.lblTitolServeis.Text = "Servicios";

            // btnCategoriaPopulares (Botó de categoria)
            this.btnCategoriaPopulares.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCategoriaPopulares.Location = new System.Drawing.Point(30, 160);
            this.btnCategoriaPopulares.Name = "btnCategoriaPopulares";
            this.btnCategoriaPopulares.Size = new System.Drawing.Size(100, 30);
            this.btnCategoriaPopulares.TabIndex = 2;
            this.btnCategoriaPopulares.Text = "Populares";
            this.btnCategoriaPopulares.UseVisualStyleBackColor = true;

            // btnCategoriaBaratos (Botó de categoria)
            this.btnCategoriaBaratos.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCategoriaBaratos.Location = new System.Drawing.Point(140, 160);
            this.btnCategoriaBaratos.Name = "btnCategoriaBaratos";
            this.btnCategoriaBaratos.Size = new System.Drawing.Size(100, 30);
            this.btnCategoriaBaratos.TabIndex = 3;
            this.btnCategoriaBaratos.Text = "Baratos";
            this.btnCategoriaBaratos.UseVisualStyleBackColor = true;

            // btnCategoriaMujeres (Botó de categoria)
            this.btnCategoriaMujeres.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCategoriaMujeres.Location = new System.Drawing.Point(250, 160);
            this.btnCategoriaMujeres.Name = "btnCategoriaMujeres";
            this.btnCategoriaMujeres.Size = new System.Drawing.Size(100, 30);
            this.btnCategoriaMujeres.TabIndex = 4;
            this.btnCategoriaMujeres.Text = "Mujeres";
            this.btnCategoriaMujeres.UseVisualStyleBackColor = true;

            // pnlServeiExemple (Panell per a un servei)
            this.pnlServeiExemple.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlServeiExemple.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlServeiExemple.Controls.Add(this.lblPuntuacioServei);
            this.pnlServeiExemple.Controls.Add(this.lblUbicacioServei);
            this.pnlServeiExemple.Controls.Add(this.lblNomServei);
            this.pnlServeiExemple.Location = new System.Drawing.Point(30, 210);
            this.pnlServeiExemple.Name = "pnlServeiExemple";
            this.pnlServeiExemple.Size = new System.Drawing.Size(354, 150);
            this.pnlServeiExemple.TabIndex = 5;

            // lblNomServei
            this.lblNomServei.AutoSize = true;
            this.lblNomServei.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNomServei.Location = new System.Drawing.Point(15, 15);
            this.lblNomServei.Name = "lblNomServei";
            this.lblNomServei.Size = new System.Drawing.Size(155, 19);
            this.lblNomServei.Text = "Corte de pelo corto";

            // lblUbicacioServei
            this.lblUbicacioServei.AutoSize = true;
            this.lblUbicacioServei.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblUbicacioServei.Location = new System.Drawing.Point(15, 45);
            this.lblUbicacioServei.Name = "lblUbicacioServei";
            this.lblUbicacioServei.Size = new System.Drawing.Size(95, 16);
            this.lblUbicacioServei.Text = "IES Bernatxia";

            // lblPuntuacioServei
            this.lblPuntuacioServei.AutoSize = true;
            this.lblPuntuacioServei.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPuntuacioServei.Location = new System.Drawing.Point(300, 15);
            this.lblPuntuacioServei.Name = "lblPuntuacioServei";
            this.lblPuntuacioServei.Size = new System.Drawing.Size(30, 16);
            this.lblPuntuacioServei.Text = "4.8";

            // btnTornarHome (Botó per tornar)
            this.btnTornarHome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTornarHome.Location = new System.Drawing.Point(30, 510);
            this.btnTornarHome.Name = "btnTornarHome";
            this.btnTornarHome.Size = new System.Drawing.Size(150, 40);
            this.btnTornarHome.TabIndex = 6;
            this.btnTornarHome.Text = "< Tornar a Home";
            this.btnTornarHome.UseVisualStyleBackColor = true;
            this.btnTornarHome.Click += new System.EventHandler(this.btnTornarHome_Click); // Assigna l'esdeveniment

            // frmServicis (Propietats del formulari)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 581);
            this.Controls.Add(this.btnTornarHome);
            this.Controls.Add(this.pnlServeiExemple);
            this.Controls.Add(this.btnCategoriaMujeres);
            this.Controls.Add(this.btnCategoriaBaratos);
            this.Controls.Add(this.btnCategoriaPopulares);
            this.Controls.Add(this.lblTitolServeis);
            this.Controls.Add(this.txtCercarServei);
            this.Controls.Add(this.lblSalutacioUsuari);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmServicis";
            this.Text = "Serveis - Pelu";

            this.pnlServeiExemple.ResumeLayout(false);
            this.pnlServeiExemple.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        // Declaracions de variables dels controls
        private System.Windows.Forms.Label lblSalutacioUsuari;
        private System.Windows.Forms.TextBox txtCercarServei;
        private System.Windows.Forms.Label lblTitolServeis;
        private System.Windows.Forms.Button btnCategoriaPopulares;
        private System.Windows.Forms.Button btnCategoriaBaratos;
        private System.Windows.Forms.Button btnCategoriaMujeres;
        private System.Windows.Forms.Panel pnlServeiExemple;
        private System.Windows.Forms.Label lblPuntuacioServei;
        private System.Windows.Forms.Label lblUbicacioServei;
        private System.Windows.Forms.Label lblNomServei;
        private System.Windows.Forms.Button btnTornarHome;
    }
}