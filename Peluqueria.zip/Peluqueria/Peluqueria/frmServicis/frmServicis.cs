﻿// Recorda canviar 'GestioPeluqueria' si el teu projecte té un altre nom
using System;
using System.Linq; // Cal afegir això per usar .OfType<>()
using System.Windows.Forms;

namespace GestioPeluqueria
{
    public partial class frmServicis : Form
    {
        public frmServicis()
        {
            InitializeComponent();
        }

        // --- ESDEVENIMENTS DE NAVEGACIÓ ---

        /// <summary>
        /// Torna al formulari Home i tanca l'actual.
        /// El nom del botó és btnTornarHome.
        /// </summary>
        private void btnTornarHome_Click(object sender, EventArgs e)
        {
            // Busca si hi ha un formulari 'frmHome' obert a la memòria
            Form frmHome = Application.OpenForms.OfType<frmHome>().FirstOrDefault();

            if (frmHome != null)
            {
                frmHome.Show(); // El mostra
            }
            else
            {
                frmHome nouHome = new frmHome(); // En crea un de nou si s'havia tancat
                nouHome.Show();
            }

            this.Close(); // Tanca aquest formulari
        }
    }
}