﻿namespace GestioPeluqueria
{
    partial class frmServicis
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            // Inicialización de controles
            this.lblSalutacioUsuari = new System.Windows.Forms.Label();
            this.txtCercarServei = new System.Windows.Forms.TextBox();
            this.lblTitolServeis = new System.Windows.Forms.Label();
            this.btnCategoriaPopulares = new System.Windows.Forms.Button();
            this.btnCategoriaBaratos = new System.Windows.Forms.Button();
            this.btnCategoriaMujeres = new System.Windows.Forms.Button();
            this.pnlServeiExemple = new System.Windows.Forms.Panel();
            this.lblNomServei = new System.Windows.Forms.Label();
            this.lblUbicacioServei = new System.Windows.Forms.Label();
            this.lblPuntuacioServei = new System.Windows.Forms.Label();
            this.btnTornarHome = new System.Windows.Forms.Button();
            // NUEVO: Inicialización del FlowLayoutPanel
            this.flpContenedorServeis = new System.Windows.Forms.FlowLayoutPanel();

            this.pnlServeiExemple.SuspendLayout();
            this.SuspendLayout();

            // --- PROPIEDADES DE LOS CONTROLES ---

            // flpContenedorServeis (NUEVO CONTENEDOR PARA LA LISTA)
            this.flpContenedorServeis.AutoScroll = true;
            this.flpContenedorServeis.Location = new System.Drawing.Point(220, 280);
            this.flpContenedorServeis.Name = "flpContenedorServeis";
            this.flpContenedorServeis.Size = new System.Drawing.Size(380, 260); // Tamaño para ver varios paneles
            this.flpContenedorServeis.TabIndex = 7;

            // lblSalutacioUsuari (Título Principal)
            this.lblSalutacioUsuari.AutoSize = true;
            this.lblSalutacioUsuari.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSalutacioUsuari.Location = new System.Drawing.Point(280, 50);
            this.lblSalutacioUsuari.Name = "lblSalutacioUsuari";
            this.lblSalutacioUsuari.Size = new System.Drawing.Size(250, 26);
            this.lblSalutacioUsuari.Text = "Serveis i Tractaments";

            // txtCercarServei 
            this.txtCercarServei.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCercarServei.Location = new System.Drawing.Point(220, 120);
            this.txtCercarServei.Name = "txtCercarServei";
            this.txtCercarServei.Size = new System.Drawing.Size(360, 26);
            this.txtCercarServei.TabIndex = 1;
            this.txtCercarServei.Text = "Buscar servicio...";
            this.txtCercarServei.ForeColor = System.Drawing.Color.Gray;
            this.txtCercarServei.GotFocus += new System.EventHandler(this.txtCercarServei_GotFocus);
            this.txtCercarServei.LostFocus += new System.EventHandler(this.txtCercarServei_LostFocus);
            this.txtCercarServei.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCercarServei_KeyDown);

            // lblTitolServeis 
            this.lblTitolServeis.AutoSize = true;
            this.lblTitolServeis.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitolServeis.Location = new System.Drawing.Point(220, 180);
            this.lblTitolServeis.Name = "lblTitolServeis";
            this.lblTitolServeis.Size = new System.Drawing.Size(91, 22);
            this.lblTitolServeis.Text = "Serveis";

            // Botones de categoría 
            this.btnCategoriaPopulares.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCategoriaPopulares.Location = new System.Drawing.Point(220, 220);
            this.btnCategoriaPopulares.Name = "btnCategoriaPopulares";
            this.btnCategoriaPopulares.Size = new System.Drawing.Size(100, 30);
            this.btnCategoriaPopulares.TabIndex = 2;
            this.btnCategoriaPopulares.Text = "Populares";
            this.btnCategoriaPopulares.UseVisualStyleBackColor = true;

            this.btnCategoriaBaratos.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCategoriaBaratos.Location = new System.Drawing.Point(330, 220);
            this.btnCategoriaBaratos.Name = "btnCategoriaBaratos";
            this.btnCategoriaBaratos.Size = new System.Drawing.Size(100, 30);
            this.btnCategoriaBaratos.TabIndex = 3;
            this.btnCategoriaBaratos.Text = "Baratos";
            this.btnCategoriaBaratos.UseVisualStyleBackColor = true;

            this.btnCategoriaMujeres.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCategoriaMujeres.Location = new System.Drawing.Point(440, 220);
            this.btnCategoriaMujeres.Name = "btnCategoriaMujeres";
            this.btnCategoriaMujeres.Size = new System.Drawing.Size(100, 30);
            this.btnCategoriaMujeres.TabIndex = 4;
            this.btnCategoriaMujeres.Text = "Mujeres";
            this.btnCategoriaMujeres.UseVisualStyleBackColor = true;

            // pnlServeiExemple (Se mantiene para no romper el código anterior, pero se ocultará)
            this.pnlServeiExemple.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlServeiExemple.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlServeiExemple.Controls.Add(this.lblPuntuacioServei);
            this.pnlServeiExemple.Controls.Add(this.lblUbicacioServei);
            this.pnlServeiExemple.Controls.Add(this.lblNomServei);
            this.pnlServeiExemple.Location = new System.Drawing.Point(220, 280);
            this.pnlServeiExemple.Name = "pnlServeiExemple";
            this.pnlServeiExemple.Size = new System.Drawing.Size(360, 150);
            this.pnlServeiExemple.TabIndex = 5;

            // lblNomServei (del panel de ejemplo)
            this.lblNomServei.AutoSize = true;
            this.lblNomServei.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNomServei.Location = new System.Drawing.Point(15, 15);
            this.lblNomServei.Name = "lblNomServei";
            this.lblNomServei.Size = new System.Drawing.Size(155, 19);
            this.lblNomServei.Text = "Corte de pelo corto";

            // lblUbicacioServei (del panel de ejemplo)
            this.lblUbicacioServei.AutoSize = true;
            this.lblUbicacioServei.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblUbicacioServei.Location = new System.Drawing.Point(15, 45);
            this.lblUbicacioServei.Name = "lblUbicacioServei";
            this.lblUbicacioServei.Size = new System.Drawing.Size(120, 16);
            this.lblUbicacioServei.Text = "IES Bernat Sarrià";

            // lblPuntuacioServei (del panel de ejemplo)
            this.lblPuntuacioServei.AutoSize = true;
            this.lblPuntuacioServei.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPuntuacioServei.Location = new System.Drawing.Point(300, 15);
            this.lblPuntuacioServei.Name = "lblPuntuacioServei";
            this.lblPuntuacioServei.Size = new System.Drawing.Size(30, 16);
            this.lblPuntuacioServei.Text = "4.8";

            // btnTornarHome 
            this.btnTornarHome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTornarHome.Location = new System.Drawing.Point(325, 550);
            this.btnTornarHome.Name = "btnTornarHome";
            this.btnTornarHome.Size = new System.Drawing.Size(150, 40);
            this.btnTornarHome.TabIndex = 6;
            this.btnTornarHome.Text = "< Tornar a Home";
            this.btnTornarHome.UseVisualStyleBackColor = true;
            this.btnTornarHome.Click += new System.EventHandler(this.btnTornarHome_Click);

            // frmServicis (Propiedades del formulario)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 650);

            // AGREGAMOS TODOS LOS CONTROLES, INCLUYENDO EL NUEVO FlowLayoutPanel
            this.Controls.Add(this.flpContenedorServeis); // <-- NUEVO
            this.Controls.Add(this.btnTornarHome);
            this.Controls.Add(this.pnlServeiExemple);
            this.Controls.Add(this.btnCategoriaMujeres);
            this.Controls.Add(this.btnCategoriaBaratos);
            this.Controls.Add(this.btnCategoriaPopulares);
            this.Controls.Add(this.lblTitolServeis);
            this.Controls.Add(this.txtCercarServei);
            this.Controls.Add(this.lblSalutacioUsuari);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmServicis";
            this.Text = "Serveis - Pelu";

            this.pnlServeiExemple.ResumeLayout(false);
            this.pnlServeiExemple.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        // Declaraciones de variables
        private System.Windows.Forms.FlowLayoutPanel flpContenedorServeis; // <-- NUEVO
        private System.Windows.Forms.Label lblSalutacioUsuari;
        private System.Windows.Forms.TextBox txtCercarServei;
        private System.Windows.Forms.Label lblTitolServeis;
        private System.Windows.Forms.Button btnCategoriaPopulares;
        private System.Windows.Forms.Button btnCategoriaBaratos;
        private System.Windows.Forms.Button btnCategoriaMujeres;
        private System.Windows.Forms.Panel pnlServeiExemple;
        private System.Windows.Forms.Label lblPuntuacioServei;
        private System.Windows.Forms.Label lblUbicacioServei;
        private System.Windows.Forms.Label lblNomServei;
        private System.Windows.Forms.Button btnTornarHome;
    }
}