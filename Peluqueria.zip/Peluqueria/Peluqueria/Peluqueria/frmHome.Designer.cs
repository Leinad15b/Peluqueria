﻿namespace GestioPeluqueria
{
    partial class frmHome
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            // Inicialización de controles
            this.lblTitolPelu = new System.Windows.Forms.Label();
            this.lblEslògan = new System.Windows.Forms.Label();
            this.lblPromocio = new System.Windows.Forms.Label();
            this.pnlEstetica = new System.Windows.Forms.Panel();
            this.lblEstetica = new System.Windows.Forms.Label();
            this.pnlPeluqueria = new System.Windows.Forms.Panel();
            this.lblPeluqueria = new System.Windows.Forms.Label();
            this.lblTitolPreus = new System.Windows.Forms.Label();
            this.dgvPreus = new System.Windows.Forms.DataGridView();
            this.btnAnarServeis = new System.Windows.Forms.Button();
            this.btnEixirApp = new System.Windows.Forms.Button();

            // Agrupación de Paneles
            this.pnlEstetica.SuspendLayout();
            this.pnlPeluqueria.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPreus)).BeginInit();
            this.SuspendLayout();

            // --- PROPIEDADES DE LOS CONTROLES ---

            // lblTitolPelu 
            this.lblTitolPelu.AutoSize = true;
            this.lblTitolPelu.Font = new System.Drawing.Font("Arial", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitolPelu.Location = new System.Drawing.Point(350, 30);
            this.lblTitolPelu.Name = "lblTitolPelu";
            this.lblTitolPelu.Size = new System.Drawing.Size(107, 45);
            this.lblTitolPelu.Text = "Pelu";

            // lblEslògan 
            this.lblEslògan.AutoSize = true;
            this.lblEslògan.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblEslògan.Location = new System.Drawing.Point(300, 80);
            this.lblEslògan.Name = "lblEslògan";
            this.lblEslògan.Size = new System.Drawing.Size(206, 18);
            this.lblEslògan.Text = "Tu peluquería de confianza";

            // lblPromocio 
            this.lblPromocio.AutoSize = true;
            this.lblPromocio.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPromocio.ForeColor = System.Drawing.Color.BlueViolet;
            this.lblPromocio.Location = new System.Drawing.Point(235, 130);
            this.lblPromocio.Name = "lblPromocio";
            this.lblPromocio.Size = new System.Drawing.Size(325, 16);
            this.lblPromocio.Text = "SOLO ESTE MES!! DESCUENTO DEL 20% EN LAVADOS";

            // pnlEstetica (Panel y eventos para filtrado)
            this.pnlEstetica.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlEstetica.Controls.Add(this.lblEstetica);
            this.pnlEstetica.Location = new System.Drawing.Point(250, 180);
            this.pnlEstetica.Name = "pnlEstetica";
            this.pnlEstetica.Size = new System.Drawing.Size(150, 100);
            this.pnlEstetica.TabIndex = 2;
            this.pnlEstetica.Click += new System.EventHandler(this.pnlEstetica_Click); // ASIGNACIÓN DEL EVENTO

            // lblEstetica (Etiqueta dentro del panel)
            this.lblEstetica.AutoSize = true;
            this.lblEstetica.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblEstetica.Location = new System.Drawing.Point(38, 39);
            this.lblEstetica.Name = "lblEstetica";
            this.lblEstetica.Size = new System.Drawing.Size(84, 22);
            this.lblEstetica.Text = "Estética";
            this.lblEstetica.Click += new System.EventHandler(this.pnlEstetica_Click); // ASIGNACIÓN DEL MISMO EVENTO

            // pnlPeluqueria (Panel y eventos para filtrado)
            this.pnlPeluqueria.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlPeluqueria.Controls.Add(this.lblPeluqueria);
            this.pnlPeluqueria.Location = new System.Drawing.Point(415, 180);
            this.pnlPeluqueria.Name = "pnlPeluqueria";
            this.pnlPeluqueria.Size = new System.Drawing.Size(150, 100);
            this.pnlPeluqueria.TabIndex = 3;
            this.pnlPeluqueria.Click += new System.EventHandler(this.pnlPeluqueria_Click); // ASIGNACIÓN DEL EVENTO

            // lblPeluqueria (Etiqueta dentro del panel)
            this.lblPeluqueria.AutoSize = true;
            this.lblPeluqueria.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPeluqueria.Location = new System.Drawing.Point(25, 39);
            this.lblPeluqueria.Name = "lblPeluqueria";
            this.lblPeluqueria.Size = new System.Drawing.Size(107, 22);
            this.lblPeluqueria.Text = "Peluquería";
            this.lblPeluqueria.Click += new System.EventHandler(this.pnlPeluqueria_Click); // ASIGNACIÓN DEL MISMO EVENTO

            // lblTitolPreus 
            this.lblTitolPreus.AutoSize = true;
            this.lblTitolPreus.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitolPreus.Location = new System.Drawing.Point(250, 310);
            this.lblTitolPreus.Name = "lblTitolPreus";
            this.lblTitolPreus.Size = new System.Drawing.Size(200, 22);
            this.lblTitolPreus.Text = "Tratamientos y precios";

            // dgvPreus (Tabla de precios)
            this.dgvPreus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPreus.Location = new System.Drawing.Point(250, 345);
            this.dgvPreus.Name = "dgvPreus";
            this.dgvPreus.ReadOnly = true; // <-- BLOQUEO DE EDICIÓN
            this.dgvPreus.Size = new System.Drawing.Size(325, 150);
            this.dgvPreus.TabIndex = 4;

            // btnAnarServeis (Botón para navegar)
            this.btnAnarServeis.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAnarServeis.Location = new System.Drawing.Point(250, 520);
            this.btnAnarServeis.Name = "btnAnarServeis";
            this.btnAnarServeis.Size = new System.Drawing.Size(150, 40);
            this.btnAnarServeis.TabIndex = 5;
            this.btnAnarServeis.Text = "Veure Serveis";
            this.btnAnarServeis.UseVisualStyleBackColor = true;
            this.btnAnarServeis.Click += new System.EventHandler(this.btnAnarServeis_Click);

            // btnEixirApp (Botón para salir)
            this.btnEixirApp.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnEixirApp.Location = new System.Drawing.Point(425, 520);
            this.btnEixirApp.Name = "btnEixirApp";
            this.btnEixirApp.Size = new System.Drawing.Size(150, 40);
            this.btnEixirApp.TabIndex = 6;
            this.btnEixirApp.Text = "Eixir";
            this.btnEixirApp.UseVisualStyleBackColor = true;
            this.btnEixirApp.Click += new System.EventHandler(this.btnEixirApp_Click);

            // frmHome (Propiedades del formulario)
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 650); // <-- TAMAÑO GRANDE
            this.Controls.Add(this.btnEixirApp);
            this.Controls.Add(this.btnAnarServeis);
            this.Controls.Add(this.dgvPreus);
            this.Controls.Add(this.lblTitolPreus);
            this.Controls.Add(this.pnlPeluqueria);
            this.Controls.Add(this.pnlEstetica);
            this.Controls.Add(this.lblPromocio);
            this.Controls.Add(this.lblEslògan);
            this.Controls.Add(this.lblTitolPelu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmHome";
            this.Text = "Home - Pelu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmHome_FormClosed);

            this.pnlEstetica.ResumeLayout(false);
            this.pnlEstetica.PerformLayout();
            this.pnlPeluqueria.ResumeLayout(false);
            this.pnlPeluqueria.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPreus)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        // Declaraciones de variables
        private System.Windows.Forms.Label lblTitolPelu;
        private System.Windows.Forms.Label lblEslògan;
        private System.Windows.Forms.Label lblPromocio;
        private System.Windows.Forms.Panel pnlEstetica;
        private System.Windows.Forms.Label lblEstetica;
        private System.Windows.Forms.Panel pnlPeluqueria;
        private System.Windows.Forms.Label lblPeluqueria;
        private System.Windows.Forms.Label lblTitolPreus;
        private System.Windows.Forms.DataGridView dgvPreus;
        private System.Windows.Forms.Button btnAnarServeis;
        private System.Windows.Forms.Button btnEixirApp;
    }
}