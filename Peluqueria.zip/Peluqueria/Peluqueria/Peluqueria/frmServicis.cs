﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace GestioPeluqueria
{
    public partial class frmServicis : Form
    {
        private List<Servei> llistaServeis;

        public frmServicis()
        {
            InitializeComponent();
            CarregarDadesServeis(); // Cargar datos al iniciar

            // Asignación de eventos de búsqueda y filtros
            this.txtCercarServei.KeyDown += new KeyEventHandler(this.txtCercarServei_KeyDown);
            this.btnCategoriaPopulares.Click += new EventHandler(this.btnCategoria_Click);
            this.btnCategoriaBaratos.Click += new EventHandler(this.btnCategoria_Click);
            this.btnCategoriaMujeres.Click += new EventHandler(this.btnCategoria_Click);

            // Mostrar todos los servicios por defecto al inicio
            MostrarLlistaServeis(llistaServeis);

            // Ocultamos el panel de ejemplo (pnlServeiExemple) que ya no se usará
            pnlServeiExemple.Visible = false;
        }

        private void CarregarDadesServeis()
        {
            // Añadimos más datos para que los filtros funcionen y muestren varios resultados
            llistaServeis = new List<Servei>();
            llistaServeis.Add(new Servei("Corte de pelo hombre", "Tallat de cabell bàsic per a home. Aquest servei inclou rentat, tallat i un assecat ràpid.", 7.00m, "Peluqueria", 4.8f));
            llistaServeis.Add(new Servei("Lavado y Secado", "Rentat i assecat ràpid amb productes professionals. Ideal per mantenir el cabell net i hidratat.", 4.50m, "Peluqueria", 4.9f));
            llistaServeis.Add(new Servei("Manicura completa", "Servei de manicura bàsic i esmalt. Inclou neteja de cutícules, llimat i massatge de mans.", 15.00m, "Estetica", 4.3f));
            llistaServeis.Add(new Servei("Pedicura express", "Tractament de peus ràpid i barat per a una cura superficial. No inclou esmaltat permanent.", 25.00m, "Estetica", 4.6f));
            llistaServeis.Add(new Servei("Tallat cabell dona llarg i tractament amb queratina", "Tallat de cabell llarg per a dones amb tècnica professional. Aquest servei també inclou un acabat amb planxes o rulls.", 45.00m, "Peluqueria", 4.5f));
            llistaServeis.Add(new Servei("Tinte de pelo", "Coloració de cabell professional. S'utilitzen tints sense amoníac que respecten la fibra capil·lar.", 28.00m, "Peluqueria", 4.0f));
            llistaServeis.Add(new Servei("Depilació cames dona", "Depilació de cames amb cera per a una pell suau i lliure de pèl durant setmanes.", 30.00m, "Estetica", 4.1f));
        }

        // --- LÓGICA DE VISUALIZACIÓN DE SERVICIOS ---

        private void MostrarLlistaServeis(List<Servei> serveisAMostrar)
        {
            // Limpia los controles existentes en el FlowLayoutPanel
            flpContenedorServeis.Controls.Clear();

            if (serveisAMostrar == null || serveisAMostrar.Count == 0)
            {
                Label lblNoResultats = new Label()
                {
                    Text = "No s'han trobat serveis amb aquests criteris.",
                    AutoSize = true,
                    Font = new Font("Arial", 12F, FontStyle.Italic),
                    ForeColor = Color.DarkGray
                };
                flpContenedorServeis.Controls.Add(lblNoResultats);
                return;
            }

            foreach (var servei in serveisAMostrar)
            {
                Panel pnlServei = CrearPanellServei(servei);
                flpContenedorServeis.Controls.Add(pnlServei);
            }
        }

        private Panel CrearPanellServei(Servei servei)
        {
            // Panel contenedor. ALTURA AUMENTADA a 190.
            Panel pnl = new Panel
            {
                BackColor = Color.WhiteSmoke,
                BorderStyle = BorderStyle.FixedSingle,
                Size = new Size(360, 190), // ALTURA AUMENTADA
                Margin = new Padding(0, 0, 0, 10) // Espacio entre paneles
            };

            // Etiqueta del Nombre (solo el nombre)
            Label lblNom = new Label
            {
                Text = servei.Nom,
                Font = new Font("Arial", 12F, FontStyle.Bold),
                Location = new Point(15, 15),
                AutoSize = true,
                // Limitamos el ancho a 220px para forzar el salto de línea y evitar el precio
                MaximumSize = new Size(220, 0)
            };
            pnl.Controls.Add(lblNom);

            // Etiqueta del Precio (Ubicado en la esquina superior derecha)
            Label lblPreu = new Label
            {
                Text = servei.Preu.ToString("C2"),
                Font = new Font("Arial", 12F, FontStyle.Bold),
                // Ajuste de POSICIÓN para garantizar que se vea completo
                Location = new Point(310, 15),
                AutoSize = true,
                ForeColor = Color.DarkGreen
            };
            pnl.Controls.Add(lblPreu);

            // Etiqueta de la Puntuación (Debajo del precio)
            Label lblPuntuacio = new Label
            {
                Text = servei.Puntuacio.ToString("F1") + " ★",
                Font = new Font("Arial", 10F, FontStyle.Bold),
                // Ajustamos la posición horizontal para que se alinee con el precio
                Location = new Point(315, 45),
                AutoSize = true
            };
            pnl.Controls.Add(lblPuntuacio);

            // Etiqueta de la Descripción 
            Label lblDescripcio = new Label
            {
                Text = servei.Descripcio,
                Font = new Font("Arial", 10F, FontStyle.Regular),
                Location = new Point(15, 65),
                AutoSize = true
            };

            // Limitamos el ancho MÁXIMO (330px) para que el texto salte de línea automáticamente
            lblDescripcio.MaximumSize = new Size(330, 0);

            pnl.Controls.Add(lblDescripcio);

            return pnl;
        }

        // --- LÓGICA DE BÚSQUEDA Y FILTRO ---

        private void txtCercarServei_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                flpContenedorServeis.Focus();
                string termeCerca = txtCercarServei.Text.Trim();
                List<Servei> serveisFiltrats;

                if (string.IsNullOrEmpty(termeCerca) || termeCerca.Equals("Buscar servicio...", StringComparison.OrdinalIgnoreCase))
                {
                    serveisFiltrats = llistaServeis;
                }
                else
                {
                    // Buscar servicios cuyo Nom o Descripcio contenga el término (insensible a mayúsculas)
                    serveisFiltrats = llistaServeis
                        .Where(s => s.Nom.IndexOf(termeCerca, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                    s.Descripcio.IndexOf(termeCerca, StringComparison.OrdinalIgnoreCase) >= 0)
                        .ToList();
                }

                MostrarLlistaServeis(serveisFiltrats);
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
        }

        private void btnCategoria_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string categoria = btn.Text;
            List<Servei> serveisFiltrats = new List<Servei>();

            if (categoria == "Mujeres")
            {
                // FILTRO MUJERES: servicios con palabras clave en nombre o descripción
                serveisFiltrats = llistaServeis
                    .Where(s => s.Nom.IndexOf("mujer", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                s.Nom.IndexOf("dona", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                s.Descripcio.IndexOf("dones", StringComparison.OrdinalIgnoreCase) >= 0)
                    .ToList();
            }
            else if (categoria == "Populares")
            {
                // FILTRO POPULARES: los 4 con mayor puntuación
                serveisFiltrats = llistaServeis.OrderByDescending(s => s.Puntuacio).Take(4).ToList();
            }
            else if (categoria == "Baratos")
            {
                // FILTRO BARATOS: los 4 con menor precio
                serveisFiltrats = llistaServeis.OrderBy(s => s.Preu).Take(4).ToList();
            }

            MostrarLlistaServeis(serveisFiltrats);
            ResaltarBoto(btn);
        }

        // --- FUNCIONES AUXILIARES Y NAVEGACIÓN ---

        private void ResaltarBoto(Button botoActiu)
        {
            // Restablecer estilos de todos los botones
            btnCategoriaPopulares.BackColor = SystemColors.ControlLight;
            btnCategoriaBaratos.BackColor = SystemColors.ControlLight;
            btnCategoriaMujeres.BackColor = SystemColors.ControlLight;

            // Resaltar el botón activo
            botoActiu.BackColor = Color.DeepSkyBlue;
        }

        private void btnTornarHome_Click(object sender, EventArgs e)
        {
            Form frmHome = Application.OpenForms.OfType<frmHome>().FirstOrDefault();
            if (frmHome != null)
            {
                frmHome.Show();
            }
            else
            {
                frmHome nouHome = new frmHome();
                nouHome.Show();
            }
            this.Close();
        }

        private void txtCercarServei_GotFocus(object sender, EventArgs e)
        {
            if (txtCercarServei.Text == "Buscar servicio...")
            {
                txtCercarServei.Text = "";
                txtCercarServei.ForeColor = Color.Black;
            }
        }

        private void txtCercarServei_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCercarServei.Text))
            {
                txtCercarServei.Text = "Buscar servicio...";
                txtCercarServei.ForeColor = Color.Gray;
            }
        }
    }
}