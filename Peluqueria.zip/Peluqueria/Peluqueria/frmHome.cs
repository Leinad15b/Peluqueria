﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

// Asegúrate de que el 'namespace' coincide con el nombre de tu proyecto
namespace GestioPeluqueria
{
    public partial class frmHome : Form
    {
        private List<Servei> llistaServeis;

        public frmHome()
        {
            InitializeComponent();
            // Asignación de eventos de Clicks a Paneles y Labels
            this.Load += new EventHandler(frmHome_Load);
            this.pnlEstetica.Click += new EventHandler(this.pnlEstetica_Click);
            this.pnlPeluqueria.Click += new EventHandler(this.pnlPeluqueria_Click);
            this.lblEstetica.Click += new EventHandler(this.pnlEstetica_Click);
            this.lblPeluqueria.Click += new EventHandler(this.pnlPeluqueria_Click);
        }

        private void frmHome_Load(object sender, EventArgs e)
        {
            CarregarDadesServeis();
            // Mostrar todos los servicios por defecto al cargar
            FiltrarServeis(null);
        }

        private void CarregarDadesServeis()
        {
            llistaServeis = new List<Servei>();

            // Afegim més dades per mostrar la funcionalitat del filtre
            llistaServeis.Add(new Servei("Corte de pelo", "Tallat de cabell bàsic per home", 7.00m, "Peluqueria", 4.5f));
            llistaServeis.Add(new Servei("Lavado y Secado", "Rentat i assecat ràpid", 4.50m, "Peluqueria", 4.8f));
            llistaServeis.Add(new Servei("Ajustado de la barba", "Arreglar la barba", 5.00m, "Barberia", 4.9f));

            // Serveis d'Estètica
            llistaServeis.Add(new Servei("Manicura", "Servei de manicura bàsic", 15.00m, "Estetica", 4.3f));
            llistaServeis.Add(new Servei("Pedicura", "Servei de pedicura", 25.00m, "Estetica", 4.6f));
            llistaServeis.Add(new Servei("Depilació cera", "Depilació de cames amb cera", 30.00m, "Estetica", 4.1f));

            // NOTA: La configuración del DataGridView se ha movido al método FiltrarServeis.
        }

        /// <summary>
        /// Mètode genèric per filtrar la llista de serveis i actualitzar el DataGridView.
        /// </summary>
        /// <param name="categoria">Nom de la categoria a filtrar (Peluqueria, Estetica, o null per a tots).</param>
        private void FiltrarServeis(string categoria)
        {
            List<Servei> serveisFiltrats;

            if (string.IsNullOrEmpty(categoria))
            {
                // Si la categoria és null, mostrem els primers 4 serveis o tots si són pocs.
                serveisFiltrats = llistaServeis.Take(4).ToList();
            }
            else
            {
                // Filtrem per la categoria específica
                serveisFiltrats = llistaServeis
                                        .Where(s => s.Categoria.Equals(categoria, StringComparison.OrdinalIgnoreCase) ||
                                                    (categoria == "Peluqueria" && s.Categoria.Equals("Barberia", StringComparison.OrdinalIgnoreCase)))
                                        .ToList();
            }

            // 1. Assignar la llista filtrada com a font de dades
            dgvPreus.DataSource = null; // Limpiar para asegurar recarga
            dgvPreus.DataSource = serveisFiltrats;

            // 2. Configurar Columnas (SOLO AHORA FUNCIONARÁ)
            // Ya que DataPropertyName es el nombre de la propiedad de la clase Servei
            if (dgvPreus.Columns.Contains("Descripcio"))
            {
                dgvPreus.Columns["Descripcio"].Visible = false;
            }
            if (dgvPreus.Columns.Contains("Puntuacio"))
            {
                dgvPreus.Columns["Puntuacio"].HeaderText = "Nota";
            }
            if (dgvPreus.Columns.Contains("Preu"))
            {
                dgvPreus.Columns["Preu"].DefaultCellStyle.Format = "C2";
                dgvPreus.Columns["Preu"].HeaderText = "Preu (€)";
            }
            if (dgvPreus.Columns.Contains("Nom"))
            {
                dgvPreus.Columns["Nom"].HeaderText = "Servei";
            }
            // Opcional: Asegurar que la categoría 'Barberia' se muestra si se selecciona 'Peluqueria'
            if (dgvPreus.Columns.Contains("Categoria"))
            {
                dgvPreus.Columns["Categoria"].Visible = false; // Normalmente no se muestra
            }


            dgvPreus.Refresh();
        }

        // --- ESDEVENIMENTS DE CATEGORIA ---

        private void pnlEstetica_Click(object sender, EventArgs e)
        {
            FiltrarServeis("Estetica");
        }

        private void pnlPeluqueria_Click(object sender, EventArgs e)
        {
            // Peluqueria engloba 'Peluqueria' y 'Barberia' para el filtro, como se ve en FiltrarServeis
            FiltrarServeis("Peluqueria");
        }

        // --- ESDEVENIMENTS DE NAVEGACIÓ I EIXIDA ---

        private void btnAnarServeis_Click(object sender, EventArgs e)
        {
            // Modularidad: Abrir Services y ocultar Home
            frmServicis formServeis = new frmServicis();
            formServeis.Show();
            this.Hide();
        }

        private void btnEixirApp_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmHome_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}