﻿// Recorda canviar 'GestioPeluqueria' si el teu projecte té un altre nom
namespace GestioPeluqueria
{
    /// <summary>
    /// Representa un servei o tractament ofert per la perruqueria.
    /// </summary>
    internal class Servei
    {
        // Utilitzem una nomenclatura adequada (PascalCase per a Propietats)
        public string Nom { get; set; }
        public string Descripcio { get; set; }
        public decimal Preu { get; set; } // Usem decimal per a precisió monetària
        public string Categoria { get; set; } // P. ex.: "Peluqueria", "Estetica"
        public float Puntuacio { get; set; } // Per a la nota (4.8)

        /// <summary>
        /// Constructor per crear un nou objecte Servei.
        /// </summary>
        public Servei(string nom, string descripcio, decimal preu, string categoria, float puntuacio)
        {
            this.Nom = nom;
            this.Descripcio = descripcio;
            this.Preu = preu;
            this.Categoria = categoria;
            this.Puntuacio = puntuacio;
        }
    }
}